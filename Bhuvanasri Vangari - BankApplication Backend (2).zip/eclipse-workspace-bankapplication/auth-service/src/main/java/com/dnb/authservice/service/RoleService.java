package com.dnb.authservice.service;

import com.dnb.authservice.enums.ERole;
import com.dnb.authservice.model.Role;
import com.dnb.authservice.repo.RoleRepository;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
@Transactional
@RequiredArgsConstructor
public class RoleService {

    private final RoleRepository roleRepository;

    public Optional<Role> findByName(ERole name) {
        return roleRepository.findByName(name);
    }

}
