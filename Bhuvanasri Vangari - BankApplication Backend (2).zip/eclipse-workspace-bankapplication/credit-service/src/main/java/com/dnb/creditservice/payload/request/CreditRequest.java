package com.dnb.creditservice.payload.request;

import com.dnb.creditservice.enums.CreditType;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.Data;

@Data
public class CreditRequest {
	private Integer userId;
	@Enumerated(EnumType.STRING)
	private CreditType creditType;
}
