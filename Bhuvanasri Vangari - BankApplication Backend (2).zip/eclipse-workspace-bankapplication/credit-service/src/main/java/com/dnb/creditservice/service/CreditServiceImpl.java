package com.dnb.creditservice.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dnb.creditservice.dto.Credit;
import com.dnb.creditservice.exceptions.IdNotFoundException;
import com.dnb.creditservice.repo.CreditRepository;

@Service("creditServiceImpl")
public class CreditServiceImpl implements CreditService {

	@Autowired
	private CreditRepository creditRepository;
	
	@Override
	public Credit createCredit(Credit credit) {
		return creditRepository.save(credit);
	}

	@Override
	public Optional<Credit> getCreditById(String creditId) throws IdNotFoundException {
		return creditRepository.findById(creditId);
	}

	@Override
	public Iterable<Credit> getAllCredits() {
		return creditRepository.findAll();
	}
	
	@Override
	public Iterable<Credit> getAllCreditsByUserId(Integer userId) throws IdNotFoundException {
		return creditRepository.findAllByUserId(userId);
	}

	@Override
	public boolean creditExistsById(String creditId) {
		if(creditRepository.existsById(creditId))return true;
		else return false;
	}

	@Override
	public boolean deleteCreditById(String creditId) throws IdNotFoundException {
		if(creditRepository.existsById(creditId)) {
			creditRepository.deleteById(creditId);
			if(creditRepository.existsById(creditId)) {
				return false;
			}
			return true;
		}
		else {
			throw new IdNotFoundException("Credit Id not found");
		}
	}

}
