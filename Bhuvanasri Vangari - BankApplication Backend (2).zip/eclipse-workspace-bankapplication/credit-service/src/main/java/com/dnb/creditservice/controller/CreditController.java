package com.dnb.creditservice.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dnb.creditservice.dto.Credit;
import com.dnb.creditservice.exceptions.DataNotFoundException;
import com.dnb.creditservice.exceptions.IdNotFoundException;
import com.dnb.creditservice.mapper.RequestToEntityMapper;
import com.dnb.creditservice.payload.request.CreditRequest;
import com.dnb.creditservice.service.CreditService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/credit")
@CrossOrigin("*")
public class CreditController {
	
	@Autowired
	private CreditService creditService;

	@Autowired
	private RequestToEntityMapper requestToEntityMapper;
	
	@PostMapping("/create")
	public ResponseEntity<?> createCredit(@Valid @RequestBody CreditRequest creditRequest){
		Credit credit = requestToEntityMapper.getAccountEntityObject(creditRequest);
		Credit credit2 = creditService.createCredit(credit);
		return new ResponseEntity(credit2,HttpStatus.CREATED);
	}
	
	@GetMapping("/{creditId}")
	public ResponseEntity<?>getCreditById(@PathVariable("creditId")String creditId) throws IdNotFoundException{
		Optional<Credit>optional=creditService.getCreditById(creditId);
		if(optional.isPresent()) {
			return ResponseEntity.ok(optional.get());
		}
		else {
			throw new IdNotFoundException("Id not found");
		}
	}
	
	@GetMapping("/all")
	public ResponseEntity<?>getAllCredits() throws DataNotFoundException{
		List<Credit>credits=(List<Credit>) creditService.getAllCredits();
		if(credits.isEmpty()) {
			throw new DataNotFoundException("Data not found");
		}
		else {
			return ResponseEntity.ok(credits);
		}
	}
	
	@GetMapping("/all/{userId}")
	public ResponseEntity<?>getAllCreditsByUserId(@PathVariable("userId")Integer userId) throws IdNotFoundException, DataNotFoundException{
		List<Credit>credits=(List<Credit>) creditService.getAllCreditsByUserId(userId);
		if(credits.isEmpty()) {
			throw new DataNotFoundException("Data not found");
		}
		else {
			return ResponseEntity.ok(credits);
		}
	}
	
	@DeleteMapping("/{creditId}")
	public ResponseEntity<?>deleteCreditById(@PathVariable("creditId")String creditId) throws IdNotFoundException{
		if(creditService.creditExistsById(creditId)) {
			creditService.deleteCreditById(creditId);
			return ResponseEntity.noContent().build();
		}
		else {
			throw new IdNotFoundException("Id is not valid");
		}
	}
}
