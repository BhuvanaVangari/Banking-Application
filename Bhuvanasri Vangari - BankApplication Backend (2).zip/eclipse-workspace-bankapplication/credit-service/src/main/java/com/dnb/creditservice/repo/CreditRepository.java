package com.dnb.creditservice.repo;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.dnb.creditservice.dto.Credit;

@Repository
public interface CreditRepository extends CrudRepository<Credit, String> {

	//select * from credit where userId = ?
	public Iterable<Credit> findAllByUserId(int userId);
}
