package com.dnb.creditservice.enums;

public enum CreditType {
 Loan,Credit_Card
}
