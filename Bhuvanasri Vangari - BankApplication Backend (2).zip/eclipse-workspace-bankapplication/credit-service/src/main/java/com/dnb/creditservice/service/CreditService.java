package com.dnb.creditservice.service;

import java.util.Optional;

import com.dnb.creditservice.dto.Credit;
import com.dnb.creditservice.exceptions.IdNotFoundException;

public interface CreditService {

	public Credit createCredit(Credit credit);
	
	public Optional<Credit>getCreditById(String creditId) throws IdNotFoundException;
	
	public Iterable<Credit>getAllCredits();
	
	public Iterable<Credit> getAllCreditsByUserId(Integer userId) throws IdNotFoundException;
		
	public boolean creditExistsById(String creditId);
	
	public boolean deleteCreditById(String creditId)throws IdNotFoundException;
	
}
