package com.dnb.creditservice.mapper;

import org.springframework.stereotype.Component;

import com.dnb.creditservice.dto.Credit;
import com.dnb.creditservice.payload.request.CreditRequest;

@Component
public class RequestToEntityMapper {
	public Credit getAccountEntityObject(CreditRequest creditRequest) {
		Credit credit = new Credit();
		credit.setUserId(creditRequest.getUserId());
		credit.setCreditType(creditRequest.getCreditType());
		return credit;
	}
}
