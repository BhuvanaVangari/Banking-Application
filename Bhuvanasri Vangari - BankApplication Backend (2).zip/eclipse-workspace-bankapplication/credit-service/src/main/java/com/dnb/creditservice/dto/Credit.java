package com.dnb.creditservice.dto;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.dnb.creditservice.enums.CreditType;
import com.dnb.creditservice.utils.CustomIdGenerator;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "credit")
public class Credit {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "credit_seq")
	@GenericGenerator(name="credit_seq",strategy="com.dnb.creditservice.utils.CustomIdGenerator",
	parameters =  {@Parameter(name=CustomIdGenerator.INCREMENT_PARAM,value="50"),
			@Parameter(name=CustomIdGenerator.FLAG_PARAMETER,value="false"),
			@Parameter(name=CustomIdGenerator.VALUE_PREFIX_PARAMETER,value="Cre_"),
			@Parameter(name=CustomIdGenerator.NUMBER_FORMAT_PARAMETER,value="%05d")}
			)
	private String creditId;
	private Integer userId;
	@Enumerated(EnumType.STRING)
	private CreditType creditType;
	private Long creditLimit=(long) 100000;
	private Boolean creditApprovalStatus=false;
}
