import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AccountRoutingModule } from './account-routing.module';
import { CreateAccountComponent } from './components/account-form/create-account/create-account.component';
import { DepositComponent } from './components/account-form/deposit/deposit.component';
import { WithdrawComponent } from './components/account-form/withdraw/withdraw.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms'
import { httpInterceptors } from '../shared/interceptors';
import { AccountService } from './services/account.service';


@NgModule({
  declarations: [
    CreateAccountComponent,
    DepositComponent,
    WithdrawComponent,
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    FormsModule,
    AccountRoutingModule
  ],
  providers: [AccountService,httpInterceptors]
})
export class AccountModule { }
