export interface IWithdraw {
    amount: number;
}
