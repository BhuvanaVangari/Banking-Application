export interface IDeposit {
    amount: number;
}
