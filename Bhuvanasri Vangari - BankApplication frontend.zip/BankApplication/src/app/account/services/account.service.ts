import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class AccountService {
  constructor(private httpClient: HttpClient,private router: Router) { }

  endpoint: string = '/api/account';

  getAccountByUserId(userId: number): Observable<any> {
    return this.httpClient.get(this.endpoint+'/user/'+userId);
  }

  createAccount(account: any): Observable<any> {
    return this.httpClient.post(this.endpoint+'/create', account);
  }

  deposit(accountId: String,amount: any): Observable<any> {
    return this.httpClient.put(this.endpoint+'/deposit/'+accountId,amount);
  }  

  withdraw(accountId: String,amount: any): Observable<any> {
    return this.httpClient.put(this.endpoint+'/withdraw/'+accountId,amount);
  }

  closeAccount(accountId: String): Observable<any> {
    return this.httpClient.post(this.endpoint+'/close/'+accountId,{});
  }
}
