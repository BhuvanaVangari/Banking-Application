import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LoanRoutingModule } from './loan-routing.module';
import { CreateLoanComponent } from './components/forms/create-loan/create-loan.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { LoanService } from './services/loan.service';
import { httpInterceptors } from '../shared/interceptors';

@NgModule({
  declarations: [CreateLoanComponent],
  imports: [CommonModule, FormsModule, HttpClientModule, LoanRoutingModule],
  providers: [LoanService, httpInterceptors],
})
export class LoanModule {}
