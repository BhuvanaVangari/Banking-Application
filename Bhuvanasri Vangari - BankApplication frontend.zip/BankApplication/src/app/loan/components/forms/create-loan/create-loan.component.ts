import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ILoan } from 'src/app/loan/models/iloan';
import { LoanService } from 'src/app/loan/services/loan.service';

@Component({
  selector: 'app-create-loan',
  templateUrl: './create-loan.component.html',
  styleUrls: ['./create-loan.component.css'],
})
export class CreateLoanComponent implements OnInit {
  loan: ILoan = {
    loanType: '',
    accountId: '',
    amount: 0,
  };
  constructor(private loanService: LoanService, private router: Router) {}

  ngOnInit(): void {}

  createLoan() {
    this.loan.accountId = JSON.parse(
      localStorage.getItem('accountDetails') || ''
    ).accountId;

    this.loanService.createLoan(this.loan).subscribe(
      (res) => {
        console.log(res);
        this.router.navigate(['/dashboard']);
      },
      (err) => {
        console.log(err);
      }
    );
  }
}
