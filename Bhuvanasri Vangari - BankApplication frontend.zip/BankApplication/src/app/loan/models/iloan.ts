export interface ILoan {
  loanType: string;
  amount: number;
  accountId: string;
}
