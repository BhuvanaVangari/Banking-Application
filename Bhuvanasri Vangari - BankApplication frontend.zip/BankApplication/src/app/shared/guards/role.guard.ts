import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RoleGuard implements CanActivate {
  constructor(private router: Router) {

  }

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
      let userDetails: any = JSON.parse(localStorage.getItem('userDetails') || '');
      console.log(userDetails);
      roles: [] = [];
      if(userDetails.roles.length > 0) { 
        if(userDetails.roles.includes('ROLE_USER')) //will happen if roles is admin or user
        {
          return true;
        }
        else {
          this.router.navigate(['/unauthorized']);
          return false;
        }
      }
      else {
        this.router.navigate(['/unauthorized']);
        return false;
      }
  }
  
}
