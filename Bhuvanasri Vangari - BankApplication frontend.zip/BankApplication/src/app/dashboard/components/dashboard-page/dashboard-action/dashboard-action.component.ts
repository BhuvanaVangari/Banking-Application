import { Component, OnInit } from '@angular/core';
import { takeUntil } from 'rxjs';

@Component({
  selector: 'app-dashboard-action',
  templateUrl: './dashboard-action.component.html',
  styleUrls: ['./dashboard-action.component.css'],
})
export class DashboardActionComponent implements OnInit {
  constructor() {}

  userDetails: any = {};
  admin: boolean = false;

  ngOnInit(): void {
    this.userDetails = JSON.parse(localStorage.getItem('userDetails') || '');

    // to check if user has admin role so that he can see close and approve loans button
    if (this.userDetails.roles.includes('ROLE_ADMIN')) {
      this.admin = true;
    }
  }
}
