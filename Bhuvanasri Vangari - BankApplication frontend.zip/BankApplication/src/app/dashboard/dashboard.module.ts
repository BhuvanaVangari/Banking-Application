import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './components/dashboard-page/dashboard/dashboard.component';
import { DashboardActionComponent } from './components/dashboard-page/dashboard-action/dashboard-action.component';
import { AccountService } from '../account/services/account.service';
import { httpInterceptors } from '../shared/interceptors';
import { HttpClientModule } from '@angular/common/http';
import { LoanService } from '../loan/services/loan.service';
import { DashboardLoansRowComponent } from './components/dashboard-page/dashboard-loans/dashboard-loans-row/dashboard-loans-row.component';
import { DashboardLoansComponent } from './components/dashboard-page/dashboard-loans/dashboard-loans.component';

@NgModule({
  declarations: [
    DashboardComponent,
    DashboardActionComponent,
    DashboardLoansComponent,
    DashboardLoansRowComponent,
  ],
  imports: [CommonModule, HttpClientModule, DashboardRoutingModule],
  providers: [AccountService, LoanService, httpInterceptors],
})
export class DashboardModule {}
