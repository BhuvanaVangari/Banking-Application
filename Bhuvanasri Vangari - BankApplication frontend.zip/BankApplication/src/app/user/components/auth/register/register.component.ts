import { Component, OnInit } from '@angular/core';
import { IRegister } from 'src/app/user/models/iregister';
import { UserService } from 'src/app/user/services/user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private userService: UserService) { }

  ngOnInit(): void {
  }

  register : IRegister = {username: '', email: '', password: '', password2 : ''}
  registerSubmit() {
  console.log('form submitted');
  console.log(JSON.stringify(this.register));
  this.userService.registerUser(this.register).subscribe((res) => {
    console.log(JSON.stringify(res));
  }, err => console.log(JSON.stringify(err)));


}

}
